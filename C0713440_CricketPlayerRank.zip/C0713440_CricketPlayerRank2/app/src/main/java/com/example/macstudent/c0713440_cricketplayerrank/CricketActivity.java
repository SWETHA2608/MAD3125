package com.example.macstudent.c0713440_cricketplayerrank;

import android.app.Application;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;




public class CricketActivity extends AppCompatActivity  {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricket);
    }
    public boolean parsing;
    public int matchDetailssubmissions;
    public ArrayList<MatchDetail> matchDetails;

    //@Override
    public void onCreate() {
        parsing = false;
        matchDetails = new ArrayList<>();
        matchDetailssubmissions = 0;


    }

    public boolean isMatchDetailsEmpty() {
        return (matchDetails.isEmpty()) ? true : false;
    }

    public void cleanMatchDetails() {
        matchDetails.clear();
        matchDetailssubmissions = 0;
    }

    public void addMatchDetails(MatchDetail data) {
        matchDetails.add(data);
        matchDetailssubmissions++;
    }
}
