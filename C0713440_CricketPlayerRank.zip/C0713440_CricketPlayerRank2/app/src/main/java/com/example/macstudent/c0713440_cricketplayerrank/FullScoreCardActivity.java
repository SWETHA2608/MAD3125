package com.example.macstudent.c0713440_cricketplayerrank;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;


public class FullScoreCardActivity extends ActionBarActivity {
    @InjectView(R.id.PlayerName)
     TextView PlayerName;
    @InjectView(R.id.PlayerScore)
    TextView PlayerScore;
    @InjectView(value = FullScoreCardActivity.Birthdate)
    TextView Birthdate;
    @InjectView(R.id.TestMatch)
    TextView TestMatch;
    @InjectView(R.id.DayMatch)
    TextView DayMatch;
    @InjectView(R.id.Catch)
    TableLayout Catch;
    @InjectView(R.id.Runs)
    LinearLayout Runs;
    @InjectView(R.id.Wicket)
    LinearLayout Wicket;
    @InjectView(R.layout.Stumping)
    LinearLayout Stumping;

    MatchDetail matchDetail;
    Context applicationContext;
    private getMatchDetailScore.TeamDetails team1 = new getMatchDetailScore.TeamDetails();
    getMatchDetailScore.TeamDetails team2 = new getMatchDetailScore.TeamDetails();
    private AddingView addingView;
    private MainView interstitial;

    //TODO INTERTITIAL ADVERTISE ca-app-pub-1709767846664941/2945331709
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_score_card);
        matchDetail = new MatchDetail();
        matchDetail.matchTitle = getIntent().getStringExtra("matchtitle");
        matchDetail.matchLink = getIntent().getStringExtra("matchlink");
        ButterKnife.inject(this);
        PlayerScore.setText(matchDetail.matchTitle);
        PlayerName.setText(matchDetail.matchLink);

        applicationContext = this;

    }

    private AddingListener getAdListener() {
        return new AddingListener() {




            // show ad block if one was found
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                interstitial.show();
            }
        };
    }
            @Override
            public void onAdLoaded() {
                findViewById(R.id.adView).setVisibility(View.VISIBLE);
                super.onAdloaded();
            }

    private class Birthdate {
    }
};







        class TeamDetails {
            public String team_id;
            public String team_name;
            public String team_logo;
            public String team_short_name;
        }

         class Inning {
            public String batting_team_id;
            public String batting_team_name;
            public String bowling_team_id;
            public String bowling_team_name;
            public String run_rate;
            public String runs;
            public String wickets;
            public String overs;
            public String over_limit;
            public String innings_numth;
            public String live_current_name;
        }


