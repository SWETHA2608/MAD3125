package com.example.macstudent.c0713440_cricketplayerrank;

/**
 * Created by macstudent on 2017-12-01.
 */

class ButterKnife {
    public static void inject(FullScoreCardActivity fullScoreCardActivity) {

    }
}
